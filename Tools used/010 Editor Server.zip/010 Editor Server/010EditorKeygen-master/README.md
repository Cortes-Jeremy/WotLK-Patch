# 010EditorKeygen
## [Download 010 Editor](http://www.sweetscape.com/download/010editor/)

## [Keygen release](https://github.com/HMBSbige/010EditorKeygen/releases)

## Network Verification

Set your [license server](https://github.com/HMBSbige/JetBrains-License-Server) listen on port 80, and change your host:

```
$YourServerIP www.sweetscape.com
```
Or

Run `010EditorServer.py` on local, then
Redirect `www.sweetscape.com` to 127.0.0.1 in hosts
```
127.0.0.1 www.sweetscape.com
```
